#include "stdafx.h"
#include "StrategyBasic.h"


StrategyBasic::StrategyBasic()
{
}


StrategyBasic::~StrategyBasic()
{
}
