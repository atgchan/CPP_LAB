#pragma once
class StrategyBasic
{
public:
	StrategyBasic();
	~StrategyBasic();
};

